# HRMS-Project
## Human Resources Management System Back End application with Java, Spring Boot, Hibernate, JpaRepository, RESTful services & PostgreSQL.


## Swagger UI 
![alt text](https://github.com/htutuncu/HRMS-Project/blob/main/swagger.PNG "Swagger")

## Swagger Updated
![alt text](https://github.com/htutuncu/HRMS-Project/blob/main/swaggerUpdate.PNG "Swagger")

## Database
![alt text](https://github.com/htutuncu/HRMS-Project/blob/main/databaseUpdate.PNG "Database")
